package view;

import dao.UsuarioDAO;
import model.Usuario;

import javax.swing.*;
import java.awt.*;
import view.LoginView;

public class CadastroUsuarioView extends JFrame {

    JTextField campoNomeCompleto;
    JTextField campoCpf;
    JTextField campoEmail;
    JTextField campoCargo;
    JTextField campoLoginUsuario;
    JPasswordField campoSenhaUsuario;
    JComboBox<String> comboPerfil;
    JButton botaoCadastrarUsuario;
    JButton botaoIrLogin;

    public CadastroUsuarioView() {

        setTitle("Cadastro de Usuario");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        //setLayout(new GridLayout(8, 2, 10, 10));
        setLayout(new BorderLayout());

        JPanel painelFormulario = new JPanel();

        painelFormulario.setLayout(
                new GridLayout(14, 2, 10, 10)
        );

        JLabel labelNomeCompleto = new JLabel("Nome Completo:");
        campoNomeCompleto = new JTextField();

        JLabel labelCpf = new JLabel("CPF:");
        campoCpf = new JTextField();

        JLabel labelEmail = new JLabel("Email:");
        campoEmail = new JTextField();

        JLabel labelCargo = new JLabel("Cargo:");
        campoCargo = new JTextField();

        JLabel labelLoginUsuario = new JLabel("Login Usuario:");
        campoLoginUsuario = new JTextField();

        JLabel labelSenhaUsuario = new JLabel("Senha:");
        campoSenhaUsuario = new JPasswordField();

        JLabel labelPerfil = new JLabel("Perfil");
        comboPerfil = new JComboBox<>();
        comboPerfil.addItem("Administrador");
        comboPerfil.addItem("Gerente");
        comboPerfil.addItem("Colaborador");
        botaoCadastrarUsuario = new JButton("Cadastrar Usuario:");
        botaoIrLogin = new JButton("Ja tenho conta");


        painelFormulario.add(labelNomeCompleto);
        painelFormulario.add(campoNomeCompleto);

        painelFormulario.add(labelCpf);
        painelFormulario.add(campoCpf);

        painelFormulario.add(labelEmail);
        painelFormulario.add(campoEmail);

        painelFormulario.add(labelCargo);
        painelFormulario.add(campoCargo);

        painelFormulario.add(labelLoginUsuario);
        painelFormulario.add(campoLoginUsuario);

        painelFormulario.add(labelSenhaUsuario);
        painelFormulario.add(campoSenhaUsuario);

        painelFormulario.add(labelPerfil);
        painelFormulario.add(comboPerfil);

        painelFormulario.add(new JLabel());
        painelFormulario.add(botaoCadastrarUsuario);

        painelFormulario.add(botaoIrLogin);

        add(painelFormulario);
        botaoCadastrarUsuario.addActionListener(e->cadastrarUsuario());
        botaoIrLogin.addActionListener(e -> {
            new LoginView();
            dispose();
        });


        setVisible(true);

    }

    public void cadastrarUsuario() {
        Usuario usuario = new Usuario();

        usuario.setNomeCompleto(campoNomeCompleto.getText());
        usuario.setCpf(campoCpf.getText());
        usuario.setEmail(campoEmail.getText());
        usuario.setCargo(campoCargo.getText());
        usuario.setLogin(campoLoginUsuario.getText());
        usuario.setSenha(new String(campoSenhaUsuario.getPassword()));
        usuario.setPerfil(comboPerfil.getSelectedItem().toString());

        UsuarioDAO dao = new UsuarioDAO();
        dao.cadastrar(usuario);
        JOptionPane.showMessageDialog(null, "Usuario cadastrado!");

        new LoginView();
        dispose();

    }
}




