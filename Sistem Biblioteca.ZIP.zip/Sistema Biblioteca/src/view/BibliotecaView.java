package view;

import javax.swing.*;
import java.awt.*;
import dao.LivroDAO;
import model.Livro;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import dao.EmprestimoDAO;
import model.Emprestimo;
import java.time.LocalDate;
import model.Usuario;
import dao.UsuarioDAO;

public class BibliotecaView extends JFrame {

    JButton botaoCadastrar;
    JButton botaoListar;
    JButton botaoEmprestar;
    JButton botaoDevolver;
    JTextField campoTitulo;
    JTextField campoAutor;
    JTextField campoIsbn;
    JTextField campoCategoria;
    JTextField campoUsuarioId;
    JTextField campoLivroId;
    JTable tabelaLivros;
    JTextField campoBusca;
    JButton botaoBuscar;
    DefaultTableModel modeloTabela;



    public BibliotecaView() {

            setTitle("Sistema Biblioteca");

            setSize(1000, 700);

            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            setLocationRelativeTo(null);

            setLayout(new BorderLayout(10, 10));

            // PAINEL FORMULÁRIO
            JPanel painelFormulario = new JPanel();

            painelFormulario.setLayout(
                    new GridLayout(14, 2, 10, 10)
            );

            JLabel labelBusca = new JLabel("Buscar:");
            campoBusca = new JTextField();

            JLabel labelUsuarioId = new JLabel("ID Usuario:");
            campoUsuarioId = new JTextField();

            JLabel labelLivroId = new JLabel("ID Livro:");
            campoLivroId = new JTextField();

            JLabel labelTitulo = new JLabel("Titulo:");
            campoTitulo = new JTextField();

            JLabel labelAutor = new JLabel("Autor:");
            campoAutor = new JTextField();

            JLabel labelIsbn = new JLabel("ISBN:");
            campoIsbn = new JTextField();

            JLabel labelCategoria = new JLabel("Categoria:");
            campoCategoria = new JTextField();


            painelFormulario.add(labelBusca);
            painelFormulario.add(campoBusca);

            painelFormulario.add(labelUsuarioId);
            painelFormulario.add(campoUsuarioId);

            painelFormulario.add(labelLivroId);
            painelFormulario.add(campoLivroId);

            painelFormulario.add(labelTitulo);
            painelFormulario.add(campoTitulo);

            painelFormulario.add(labelAutor);
            painelFormulario.add(campoAutor);

            painelFormulario.add(labelIsbn);
            painelFormulario.add(campoIsbn);

            painelFormulario.add(labelCategoria);
            painelFormulario.add(campoCategoria);

            // BOTÕES
            JPanel painelBotoes = new JPanel();

            painelBotoes.setLayout(
                    new GridLayout(2, 2, 10, 10)
            );

            botaoCadastrar = new JButton("Cadastrar Livro");
            botaoListar = new JButton("Listar Livros");
            botaoEmprestar = new JButton("Realizar Emprestimo");
            botaoDevolver = new JButton("Devolver Livro");
            botaoBuscar = new JButton("Buscar Livro");

            painelBotoes.add(botaoCadastrar);
            painelBotoes.add(botaoListar);
            painelBotoes.add(botaoEmprestar);
            painelBotoes.add(botaoDevolver);
            painelBotoes.add(botaoBuscar);

            // TABELA
            modeloTabela = new DefaultTableModel();

            modeloTabela.addColumn("ID");
            modeloTabela.addColumn("Titulo");
            modeloTabela.addColumn("Autor");
            modeloTabela.addColumn("ISBN");
            modeloTabela.addColumn("Categoria");
            modeloTabela.addColumn("Disponivel");

            tabelaLivros = new JTable(modeloTabela);

            JScrollPane scrollPane =
                    new JScrollPane(tabelaLivros);

            // ADICIONAR NA TELA
            add(painelFormulario, BorderLayout.NORTH);

            add(scrollPane, BorderLayout.CENTER);

            add(painelBotoes, BorderLayout.SOUTH);

            // EVENTOS
            botaoCadastrar.addActionListener(
                    e -> cadastrarLivro()
            );

            botaoListar.addActionListener(
                    e -> listarLivros()
            );

            botaoEmprestar.addActionListener(
                    e -> emprestarLivro()
            );

            botaoBuscar.addActionListener(
                    e -> buscarLivro()
            );




        setVisible(true);
    }


    public void cadastrarLivro() {

        Livro livro = new Livro();

        livro.setTitulo(campoTitulo.getText());
        livro.setAutor(campoAutor.getText());
        livro.setIsbn(campoIsbn.getText());
        livro.setCategoria(campoCategoria.getText());
        livro.setDisponivel(true);
        LivroDAO dao = new LivroDAO();

        dao.cadastrar(livro);

        JOptionPane.showMessageDialog(null, "Livro cadastrado!");

    }

    public void listarLivros(){

        modeloTabela.setRowCount(0);
        LivroDAO dao = new LivroDAO();
        ArrayList<Livro> livros = dao.listarLivros();
        for (Livro livro : livros){

            modeloTabela.addRow(new Object[]{

                    livro.getId(),
                    livro.getTitulo(),
                    livro.getAutor(),
                    livro.getIsbn(),
                    livro.getCategoria(),
                    livro.isDisponivel()
            });

        }
    }

    public void emprestarLivro(){

        Emprestimo emprestimo = new Emprestimo();

        emprestimo.setUsuarioId(
                Integer.parseInt(
                        campoUsuarioId.getText()
                )
        );

        emprestimo.setLivroId(
                Integer.parseInt(
                        campoLivroId.getText()
                )
        );

        emprestimo.setDataEmprestimo(
                LocalDate.now()
        );

        emprestimo.setDataDevolucao(
                LocalDate.now().plusDays(7)
        );

        EmprestimoDAO dao = new EmprestimoDAO();

        dao.realizarEmprestimo(emprestimo);

        JOptionPane.showMessageDialog(null,"Emprestimo realizado!");

        listarLivros();

    }

    public void buscarLivro(){

        modeloTabela.setRowCount(0);

        LivroDAO dao = new LivroDAO();

        ArrayList<Livro> livros = dao.buscarPorTitulo(campoBusca.getText());

        for (Livro livro : livros){

            modeloTabela.addRow(new Object[]{

                    livro.getId(),
                    livro.getTitulo(),
                    livro.getAutor(),
                    livro.getIsbn(),
                    livro.getCategoria(),
                    livro.isDisponivel()
            });
        }
    }


}

