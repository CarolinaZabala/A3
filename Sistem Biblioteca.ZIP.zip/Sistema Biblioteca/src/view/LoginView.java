package view;

import dao.UsuarioDAO;

import javax.swing.*;
import java.awt.*;

import view.BibliotecaView;

public class LoginView  extends JFrame  {

    JTextField campoLogin;

    JPasswordField campoSenha;

    JButton botaoEntrar;

    public LoginView(){

        setTitle("Sistema Biblioteca");

        setSize(400, 400);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLocationRelativeTo(null);

        setLayout(new GridLayout(3, 2, 10, 10));

        JLabel labelLogin =
                new JLabel("Login:");

        campoLogin = new JTextField();

        JLabel labelSenha = new JLabel("Senha:");

        campoSenha = new JPasswordField();

        botaoEntrar = new JButton("Entrar");

        add(labelLogin);

        add(campoLogin);

        add(labelSenha);

        add(campoSenha);

        add(new JLabel());

        add(botaoEntrar);

        botaoEntrar.addActionListener(e -> fazerLogin());

        setVisible(true);

    }

    public void fazerLogin(){

        String login = campoLogin.getText();

        String senha = new String(campoSenha.getPassword());

        if (login.isEmpty() || senha.isEmpty()) {
            JOptionPane.showMessageDialog(null,"Preencha login e senha!");
            return;
        }

        UsuarioDAO usuarioDAO = new UsuarioDAO();

        boolean logado = usuarioDAO.login(login, senha);

        if(logado){

            JOptionPane.showMessageDialog(null,"Login realizado!");

            new BibliotecaView();

            dispose();
    } else {
            JOptionPane.showMessageDialog(null, "Login invalido!");
        }
        }
}
