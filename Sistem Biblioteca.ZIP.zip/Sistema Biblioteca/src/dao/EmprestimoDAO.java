package dao;

import database.ConnectionFactory;
import model.Emprestimo;

import java.sql.Connection;
import java.sql.PreparedStatement;

import java.sql.ResultSet;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;


public class EmprestimoDAO {

    public void realizarEmprestimo(Emprestimo emprestimo){

        String sql =
                "INSERT INTO emprestimos " +
                        "(usuario_id, livro_id, data_emprestimo, data_devolucao) " +
                        "VALUES (?, ?, ?, ?)";

        try {

            Connection connection =
                    ConnectionFactory.getConnection();

            String verificarLivro =
                    "SELECT disponivel FROM livros WHERE id = ?";

            PreparedStatement verificarStatement =
                    connection.prepareStatement(verificarLivro);

            verificarStatement.setInt(
                    1,
                    emprestimo.getLivroId()
            );

            ResultSet resultSet =
                    verificarStatement.executeQuery();

            if (resultSet.next()) {

                boolean disponivel =
                        resultSet.getBoolean("disponivel");

                if (!disponivel){

                    System.out.println("Livro indisponivel");
                    return;
                }
            }

            PreparedStatement statement =
                    connection.prepareStatement(sql);

            statement.setInt(1, emprestimo.getUsuarioId());
            statement.setInt(2, emprestimo.getLivroId());

            statement.setDate(
                    3,
                    java.sql.Date.valueOf(
                            emprestimo.getDataEmprestimo()
                    )
            );

            statement.setDate(
                    4,
                    java.sql.Date.valueOf(
                            emprestimo.getDataDevolucao()
                    )
            );


            statement.execute();



            String sqlLivro =
                    "UPDATE livros SET disponivel = false WHERE id =?";

            PreparedStatement statementLivro =
                    connection.prepareStatement(sqlLivro);

            statementLivro.setInt(
                    1,
                    emprestimo.getLivroId()
            );


            statementLivro.execute();


            System.out.println("Emprestimo realizado!");

        } catch (Exception e){

            System.out.println("Erro:");
            System.out.println(e.getMessage());
        }

    }

    public void devolverLivro(int livroId){

        try {

            Connection connection =
                    ConnectionFactory.getConnection();

            String sql =
                    "UPDATE livros " +
                            "SET disponivel = true " +
                            "WHERE id = ?";

            PreparedStatement statement =
                    connection.prepareStatement(sql);

            statement.setInt(1, livroId);

            statement.execute();

            System.out.println("Livro devolvido!");

        } catch (Exception e){

            System.out.println("Erro:");
            System.out.println(e.getMessage());

        }
    }

    public void calcularMulta(LocalDate dataDevolucao){

        LocalDate hoje =
                LocalDate.now();

        if (hoje.isAfter(dataDevolucao)) {

            long diasAtraso =
                    ChronoUnit.DAYS.between(
                            dataDevolucao,
                            hoje
                    );
            double multa =
                    diasAtraso * 2.0;

            System.out.println("Livro atrasado!");

            System.out.println("Dias de atraso: " + diasAtraso);

            System.out.println("Multa: R$ " + multa);

        } else {

            System.out.println("Sem atraso!");

        }
    }
}
