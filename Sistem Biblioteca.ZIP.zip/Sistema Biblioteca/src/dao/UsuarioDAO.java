package dao;

import database.ConnectionFactory;
import model.Usuario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UsuarioDAO {

    public void cadastrar(Usuario usuario){

        String sql =
                "INSERT INTO usuarios " +
                        "(nome_completo, cpf, email, cargo ,login, senha, perfil) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection connection =
                    ConnectionFactory.getConnection();

            PreparedStatement statement =
                    connection.prepareStatement(sql);

            statement.setString(1, usuario.getNomeCompleto());
            statement.setString(2, usuario.getCpf());
            statement.setString(3, usuario.getEmail());
            statement.setString(4, usuario.getCargo());
            statement.setString(5, usuario.getLogin());
            statement.setString(6, usuario.getSenha());
            statement.setString(7, usuario.getPerfil());

            statement.executeUpdate();

            System.out.println("Usuario cadastrado! ");

        } catch (Exception e){

            System.out.println("Erro: ");
            System.out.print(e.getMessage());

        }
    }

    public boolean login(String login, String senha){
        String sql =
                "SELECT * FROM usuarios " +
                        "WHERE login = ? AND senha = ?";

        try {
            Connection connection =
                    ConnectionFactory.getConnection();

            PreparedStatement statement =
                    connection.prepareStatement(sql);

            statement.setString(1, login);
            statement.setString(2, senha);

            ResultSet resultSet =
                    statement.executeQuery();

            return resultSet.next();

        } catch (Exception e){

            System.out.println("Erro: ");
            System.out.print(e.getMessage());

            return false;
        }
    }
    public boolean existeUsuario() {
        String sql = "SELECT * FROM usuarios LIMIT 1";
        try {
            Connection connection =
                    ConnectionFactory.getConnection();
            PreparedStatement statement =
                    connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();
            return resultSet.next();
          } catch (Exception e) {
            System.out.println("Erro");
            System.out.println(e.getMessage());
            return false;
        }
    }
}
