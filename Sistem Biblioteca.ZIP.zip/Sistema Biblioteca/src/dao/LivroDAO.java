
package dao;

import database.ConnectionFactory;
import model.Livro;

import java.sql.ResultSet;

import java.sql.Connection;
import java.sql.PreparedStatement;

import java.util.ArrayList;
import java.sql.ResultSet;


public class LivroDAO {

    public void cadastrar(Livro livro) {

            String sql =
                    "INSERT INTO livros " +
                            "(titulo, autor, isbn, categoria, disponivel) " +
                            "VALUES (?, ?, ?, ?, ?)";

            try {
                Connection connection =
                        ConnectionFactory.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql);

                statement.setString(1, livro.getTitulo());
                statement.setString(2, livro.getAutor());
                statement.setString(3, livro.getIsbn());
                statement.setString(4, livro.getCategoria());
                statement.setBoolean(5, livro.isDisponivel());

                statement.execute();

                System.out.println("Livro cadastrado! ");

            } catch (Exception e) {

                System.out.println("Erro: ");
                System.out.println(e.getMessage());
            }
        }
        public void listar(){
        String sql = "Select * FROM livros";

        try {

            Connection connection =
                    ConnectionFactory.getConnection();

            PreparedStatement statement =
                    connection.prepareStatement(sql);

            ResultSet resultSet =
                    statement.executeQuery();

            while(resultSet.next()){

                System.out.println("ID: "+
                        resultSet.getInt("id"));

                System.out.println("Titulo: "+
                        resultSet.getString("titulo"));

                System.out.println("Autor: "+
                        resultSet.getString("autor"));

                System.out.println("ISBN: "+
                        resultSet.getString("isbn"));

                System.out.println("----------");

            }
        } catch (Exception e){

            System.out.println("Erro: ");
            System.out.println(e.getMessage());
        }
        }

        public void deletar(int id){

        String sql = "DELETE FROM livros WHERE id = ? ";

        try {

            Connection connection =
                    ConnectionFactory.getConnection();

            PreparedStatement statement =
                    connection.prepareStatement(sql);

            statement.setInt(1, id);

            statement.execute();

            System.out.println("Livro deletado!");

        } catch (Exception e ) {

            System.out.println("Erro: ");
            System.out.println(e.getMessage());
        }
        }

        public void atualizar(Livro livro){

        String sql =
                "UPDATE livros " +
                        "SET titulo = ?, autor = ?, isbn = ?, categoria = ?, disponivel = ? " +
                        "WHERE id = ?";

        try {

            Connection connection =
                    ConnectionFactory.getConnection();

            PreparedStatement statement =
                    connection.prepareStatement(sql);

            statement.setString(1, livro.getTitulo());
            statement.setString(2, livro.getAutor());
            statement.setString(3, livro.getIsbn());
            statement.setString(4, livro.getCategoria());
            statement.setBoolean(5, livro.isDisponivel());
            statement.setInt(6, livro.getId());

            statement.execute();

            System.out.println("Livro atualizado! ");
        } catch (Exception e){

            System.out.println("Erro: ");
            System.out.println(e.getMessage());
        }
        }

        public ArrayList<Livro> listarLivros() {

        ArrayList<Livro> livros = new ArrayList<>();

        String sql = "SELECT * FROM livros";

        try {

            Connection connection =
                    ConnectionFactory.getConnection();

            PreparedStatement statement =
                    connection.prepareStatement(sql);

            ResultSet resultSet=
                    statement.executeQuery();

            while (resultSet.next()) {

                Livro livro = new Livro();

                livro.setId(resultSet.getInt("id"));

                livro.setTitulo(resultSet.getString("titulo"));

                livro.setAutor(resultSet.getString("autor"));

                livro.setIsbn(resultSet.getString("isbn"));

                livro.setCategoria(resultSet.getString("categoria"));

                livro.setDisponivel(resultSet.getBoolean("disponivel"));

                livros.add(livro);
            }
        } catch (Exception e) {

            System.out.println("Erro: ");
            System.out.println(e.getMessage());
        }

        return livros;
        }

        public ArrayList<Livro> buscarPorTitulo(String titulo){

        ArrayList<Livro> livros = new ArrayList<>();

        String sql =
                "SELECT * FROM livros " +
                        " WHERE titulo LIKE ?";

                try {

                    Connection connection =
                            ConnectionFactory.getConnection();

                    PreparedStatement statement =
                            connection.prepareStatement(sql);

                            statement.setString(1, "%" + titulo + "%");

                    ResultSet resultSet = statement.executeQuery();

                    while (resultSet.next()) {

                        Livro livro = new Livro();

                        livro.setId(resultSet.getInt("id"));

                        livro.setTitulo(resultSet.getString("titulo"));

                        livro.setAutor(resultSet.getString("autor"));

                        livro.setIsbn(resultSet.getString("isbn"));

                        livro.setCategoria(resultSet.getString("categoria"));

                        livro.setDisponivel(resultSet.getBoolean("disponivel"));

                        livros.add(livro);

                    }

                } catch (Exception e){

                    System.out.println("Erro:");
                    System.out.println(e.getMessage());

                }

                return livros;
        }
    }



        